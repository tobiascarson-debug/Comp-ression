# Changes to __init__, _nexus, _pipeline, save, _load_zenith and small helpers.

    def __init__(self, storage_dir: str = "./codex_zenith", target_ratio: float = 10_000.0, zstd_level: int = 3, pattern_cap: int = 25000):
        self.storage_dir = Path(storage_dir)
        self.storage_dir.mkdir(parents=True, exist_ok=True)
        self.target_ratio = target_ratio
        self.zstd_level = zstd_level
        self.pattern_cap = pattern_cap

        # Z: The Zenith components
        self.codex_index: Dict[str, CodexEntry] = {}       # Codex Index
        self.metadata_map: Dict[str, Dict] = {}            # Metadata Map
        self.delta_store: Dict[str, bytes] = {}            # Delta Storage (content_hash -> ref bytes)
        self.vector_store: Dict[str, List[float]] = {}     # Vector Coordinates
        self.pattern_store: Dict[str, bytes] = {}          # reusable patterns (V3)
        self.global_fingerprint: Dict[str, str] = {}       # exact + canonical → atom

        # Use a moderate default zstd level (configurable); avoid forcing threads=-1
        self.cctx = zstd.ZstdCompressor(level=self.zstd_level)
        self.dctx = zstd.ZstdDecompressor()
        self._load_zenith()

    def _nexus(self, payload: bytes, dtype: str) -> Tuple[bytes, str, Optional[str], List[str]]:
        """
        Return (blob, content_hash, delta_ref, pattern_refs).

        Important: compute content_hash and canonical fingerprint after veracity
        (so the content_hash corresponds to the bytes we actually store).
        """
        # V4 path first (may transform payload)
        payload = self._veracity(payload)
        # canonical and exact content hash are based on the post-veracity bytes
        content_hash = xxhash.xxh64(payload).hexdigest()
        canon = self._canonical_fingerprint(payload)

        # Fast-paths for already-known atoms (either exact hash or canonical)
        if content_hash in self.global_fingerprint:
            # Already stored exactly — return no blob, but reference the atom id
            return b"", self.global_fingerprint[content_hash], None, []
        if canon in self.global_fingerprint:
            return b"", self.global_fingerprint[canon], None, []

        # pattern matching (may register patterns)
        payload_after_patterns, pattern_refs = self._pattern_match(payload)

        # Build zstd dictionary data from a bounded selection of patterns.
        dict_data = None
        if self.pattern_store:
            # Use up to 256 patterns but limit overall memory use (take shortest patterns first)
            patterns = sorted(self.pattern_store.values(), key=len)[:256]
            if patterns:
                dict_data = b"".join(patterns)

        # Compress using a dictionary if available; fall back to the engine compressor
        try:
            if dict_data:
                zdict = zstd.ZstdCompressionDict(dict_data)
                cctx = zstd.ZstdCompressor(level=self.zstd_level, dict_data=zdict)
                blob = cctx.compress(payload_after_patterns)
            else:
                blob = self.cctx.compress(payload_after_patterns)
        except Exception:
            # Last resort
            blob = self.cctx.compress(payload_after_patterns)

        # No delta logic implemented here: delta_ref remains None
        return blob, content_hash, None, pattern_refs

    def _pipeline(self, batch: List[Any]) -> List[str]:
        hashes = []
        for item in batch:
            dtype, payload, meta = self._unify(item)

            # Do not compute final content_hash until after nexus/veracity. We'll
            # generate a provisional canon to skip some work, but the canonical and
            # final content hash are set inside _nexus.
            provisional_canon = self._canonical_fingerprint(payload)

            # If we already know the canonical fingerprint -> map to existing atom
            if provisional_canon in self.global_fingerprint:
                hashes.append(self.global_fingerprint[provisional_canon])
                continue

            blob, content_hash, delta_ref, pattern_refs = self._nexus(payload, dtype)
            original_size = len(payload)
            compressed_size = len(blob) if blob is not None else 0
            ratio = original_size / max(compressed_size, 1)
            tokens = self._tokenize(payload)
            vector = self._make_vector(tokens, payload)

            # Ensure canon is stored with the entry so it can be restored
            canon = self._canonical_fingerprint(self._veracity(payload))

            entry = CodexEntry(
                content_hash=content_hash,
                compressed_blob=blob,
                original_size=original_size,
                compressed_size=compressed_size,
                ratio=ratio,
                data_type=dtype,
                metadata={**meta, "ingest_ts": time.time(), "canon": canon},
                vector=vector,
                delta_ref=delta_ref,
                pattern_refs=pattern_refs,
            )

            # Persist in-memory stores
            self.codex_index[content_hash] = entry
            self.metadata_map[content_hash] = entry.metadata
            self.vector_store[content_hash] = vector
            if delta_ref:
                self.delta_store[content_hash] = delta_ref.encode()

            # Register fingerprints: both exact and canonical map to the canonical atom id
            self.global_fingerprint[content_hash] = content_hash
            if canon:
                self.global_fingerprint[canon] = content_hash

            hashes.append(content_hash)
        return hashes

    def save(self) -> None:
        path = self.storage_dir / "codex_index.msgpack"
        serializable = {
            h: {
                "content_hash": e.content_hash,
                "compressed_blob": e.compressed_blob,
                "original_size": e.original_size,
                "compressed_size": e.compressed_size,
                "ratio": e.ratio,
                "data_type": e.data_type,
                "metadata": e.metadata,
                "vector": e.vector,
                "delta_ref": e.delta_ref,
                "pattern_refs": e.pattern_refs,
                "timestamp": e.timestamp,
            }
            for h, e in self.codex_index.items()
        }
        # Also persist auxiliary stores (pattern_store and delta_store)
        aux = {
            "pattern_store": self.pattern_store,
            "delta_store": {k: v.decode() if isinstance(v, bytes) else v for k, v in self.delta_store.items()},
            "global_fingerprint": self.global_fingerprint,
        }
        with open(path, "wb") as f:
            f.write(msgpack.packb({"entries": serializable, "aux": aux}, use_bin_type=True))

    def _load_zenith(self) -> None:
        path = self.storage_dir / "codex_index.msgpack"
        if not path.exists():
            return
        with open(path, "rb") as f:
            data = msgpack.unpackb(f.read(), raw=False)
        entries = data.get("entries", {})
        aux = data.get("aux", {})

        for h, d in entries.items():
            # ensure fields exist; this will raise if incompatible, but that's okay for now
            entry = CodexEntry(
                content_hash=d["content_hash"],
                compressed_blob=d.get("compressed_blob", b""),
                original_size=d.get("original_size", 0),
                compressed_size=d.get("compressed_size", 0),
                ratio=d.get("ratio", 0.0),
                data_type=d.get("data_type", "binary"),
                metadata=d.get("metadata", {}),
                vector=d.get("vector", []),
                delta_ref=d.get("delta_ref"),
                pattern_refs=d.get("pattern_refs", []),
                timestamp=d.get("timestamp", time.time()),
            )
            self.codex_index[h] = entry
            self.metadata_map[h] = entry.metadata
            self.vector_store[h] = entry.vector
            if entry.delta_ref:
                self.delta_store[h] = entry.delta_ref.encode()

            # restore exact fingerprint mapping
            self.global_fingerprint[h] = h
            # restore canonical mapping if stored in metadata
            canon = entry.metadata.get("canon")
            if canon:
                self.global_fingerprint[canon] = h

        # restore pattern store and delta store if present (aux may contain raw bytes)
        ps = aux.get("pattern_store", {})
        if isinstance(ps, dict):
            # limit restore to the configured cap
            for k, v in list(ps.items())[: self.pattern_cap]:
                self.pattern_store[k] = v

        ds = aux.get("delta_store", {})
        if isinstance(ds, dict):
            for k, v in ds.items():
                self.delta_store[k] = v.encode() if isinstance(v, str) else v

        gf = aux.get("global_fingerprint", {})
        if isinstance(gf, dict):
            # merge but don't overwrite exact entries already set above
            for k, v in gf.items():
                if k not in self.global_fingerprint:
                    self.global_fingerprint[k] = v