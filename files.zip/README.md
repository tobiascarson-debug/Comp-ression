# XYZ Knowledge Library — Codex (xyz-knowledge-codex)

A prototype "Massive Data Compression Engine" for deduplication, pattern extraction,
and high-compression yield. Implements the V1→V4 → X → Y → Z pipeline in a single
Python module (`xyz_codex_engine.py`).

This repository is published and copyrighted by Tobias Gordon Carson (2026).
Licensed under the MIT License (see LICENSE).

Quick start
-----------
1. Create a Python virtual environment and install dependencies:
   ```bash
   python -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt